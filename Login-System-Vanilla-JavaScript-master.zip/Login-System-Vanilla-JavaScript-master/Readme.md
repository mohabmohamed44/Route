## Description

This is a simple web application that allows users to sign up and log in. It is built with HTML, CSS, and JavaScript.

## Features

- User registration
- User login
- User logout
- User profile page
- Regular Expression Validation

## Installation

1. Clone the repository:
   ```
   git clone https://github.com/mohabmohamed44/Login-System-Vanilla-JavaScript.git
   ```
2. Open `index.html` in your browser.
